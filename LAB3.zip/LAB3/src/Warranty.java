
import java.time.LocalDate;


public class Warranty {

    public static void main(String[] args) {
        LocalDate currDate = LocalDate.of(27, 1, 20);
        LocalDate ldNew = currDate.plusYears(2);
        currDate.plusMonths(2);
        System.out.println("Warranty ends: " + ldNew.getMonthValue() + "/ " + ldNew.getYear());
    }

}