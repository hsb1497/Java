
public class StringOps {
	
	    String manipulate(String str, int choice) {
	        String result = "";
	        
	        switch(choice) {
	        case 1:
	            result = concat(str);
	            break;
	        case 2:
	            result = replaceWithHash(str);
	            break;
	        case 3:
	            result = removeDuplicate(str);
	            break;
	        case 4:
	            result = oddToUpper(str);
	        }
	        return result;
	    }
	    
	    String concat(String str) {
	        return str + str;
	    }
	    
	    String replaceWithHash(String str) {
	        for(int i=0; i<str.length(); i=i+2) {
	            str = str.substring(0, i) + "#" + str.substring(i+1);
	        }
	        return str;
	    }
	    
	    String removeDuplicate(String str) {
	        String res = "";
	        
	        int visited[] = new int[str.length()];
	        char[] strArr = str.toCharArray();
	        
	        for(int i=0; i<str.length()-1; i++) {
	            for(int j=i+1; j<str.length(); j++) {
	                if(strArr[i] == strArr[j]) {
	                    visited[j] = 1;
	                }
	            }
	        }
	        
	        for(int i=0; i<str.length(); i++) {
	            if (visited[i] == 0) {
	                res = res + strArr[i];
	            }
	        }
	        
	        return res;
	    }
	    
	    String oddToUpper(String str) {
	        String res = "";
	        char[] strArr = str.toCharArray();
	        
	        for(int i=0; i<str.length(); i=i+2) {
	            strArr[i] = Character.toUpperCase(strArr[i]);
	        }
	        
	        for(int i=0; i<str.length(); i++) {
	            res = res + strArr[i];
	        }
	        
	        return str;
	    }
}



