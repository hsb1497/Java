import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZoneId;


public class TimeZone {

	public static void main(String[] args) {
		
		ZoneId zone1=ZoneId.of("Europe/Berlin");
		ZoneId zone2=ZoneId.of("Europe/Berlin");
		
		LocalDate dateNow1=LocalDate.now(zone1);
		LocalDate dateNow2=LocalDate.now(zone2);
		
		LocalTime timeNow1=LocalTime.now(zone1);
		LocalTime timeNow2=LocalTime.now(zone2);
		
		System.out.println(dateNow1 + " "+timeNow1);
		System.out.println(dateNow2 + " "+timeNow2);

	}

}
