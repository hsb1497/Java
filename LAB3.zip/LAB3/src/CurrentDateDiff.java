import java.time.LocalDate;
import java.time.Period;
public class CurrentDateDiff {

	public static void main(String[] args) {
		
		LocalDate currDate=LocalDate.now();
		LocalDate userDate=LocalDate.of(2017,11,06);
		
		Period p=Period.between(userDate,currDate);
		
		System.out.println(p.getYears() + " years" + p.getMonths()+"months and"+p.getDays()+"days");

	}

}
