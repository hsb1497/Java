
import java.util.Scanner;


public class StringOpsMain {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StringOps op = new StringOps();
        
        System.out.println("Enter a string: ");
        String str = sc.next();
        
        System.out.println("Sting ops: ");
        System.out.println("1. Add String to itself");
        System.out.println("2. Replace odd positions with #");
        System.out.println("3. Remove duplicate characters in the String");
        System.out.println("4. Change odd characters to upper case");
        int choice = sc.nextInt();
        
        String result = op.manipulate(str, choice);
        System.out.println(result);
        sc.close();
    }

}
