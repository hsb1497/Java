import java.util.Arrays;


public class StringSort {

	public static void main(String[] args) {
		
		 String[] strArr={"aha","hjksaf","efahf","ecgfhga","fsfahg"};
		 Arrays.sort(strArr);
		 int strArrLen=strArr.length;
		 int halfSize=(strArrLen % 2==0)?strArrLen/2 :strArrLen/2 +1;
		 
		 for(int i=0;i<strArrLen;i++)
		 {
			 strArr[i]=(i<halfSize)? strArr[i].toUpperCase(): strArr[i].toLowerCase();
		 }
		 
		 for(int i=0;i<strArrLen;i++)
		 {
			 System.out.println(strArr[i]+" ");
		 }

	}

}
