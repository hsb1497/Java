import java.time.LocalDate;
import java.time.Period;

public class TwoDatesDiff {

    public static void main(String[] args) {
        LocalDate currDate = LocalDate.of(2027, 1, 16);
        LocalDate userDate = LocalDate.of(2017, 11, 6);

        Period p = Period.between(userDate, currDate);

        System.out.println(p.getYears() + " years, " + p.getMonths() +
                " months, and " + p.getDays() + " days");
    }

}

