import java.util.ArrayList;
import java.util.List;


public class Lab7_5 {
	public static void main(String[] args) {
		List<User> users = new ArrayList<>();
		users.add(new User("Cadbury", 100));
		users.add(new User("Namkeen", 50));
		users.add(new User("Soft Drinks", 100));

		users.forEach(user -> {
			System.out.println("Product Name : " + user.getProductName() + ", Price : " + user.getPrice());
		});
	}
}


